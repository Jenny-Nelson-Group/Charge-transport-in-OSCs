It's terrifying what the brain forgets, but the machine remembers.

```
Delivered-To: jarvist@gmail.com
Date: Mon, 6 Jul 2009 23:35:25 +0100
Subject: projection using a counterpoise method
From: James Kirkpatrick <james.a.kirkpatrick@googlemail.com>
To: Jarvist Frost <jarvist@gmail.com>, r.mackenzie@imperial.ac.uk

Hi,

I have - I think - slightly improved the method for computing transfer
integrals by using a counterpoise calculation. I include the script files, a
test case and an explanation of how it works.
```

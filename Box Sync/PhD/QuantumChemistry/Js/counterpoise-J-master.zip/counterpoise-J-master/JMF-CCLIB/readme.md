From: Jarvist Moore Frost <jarvist@...>
To: James Kirkpatrick <james.a.kirkpatrick@...>
Cc: <r.mackenzie@...>

Hi guys,

Here's a little variation with cclib, uses the same dim/part1/part2
structure as James'.
Makes use of a IOp(6/7=3) request for the molA + molB calculations.

Values are off due to rounding errors c.f. James' code, I'm not sure
whether it makes a serious difference.

Jarv

